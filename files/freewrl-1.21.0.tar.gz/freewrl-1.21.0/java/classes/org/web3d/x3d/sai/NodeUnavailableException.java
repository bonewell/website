package org.web3d.x3d.sai;

public class NodeUnavailableException extends X3DException {
	public NodeUnavailableException() {
		super();
	}
	public NodeUnavailableException(String msg) {
		super(msg);
	}
}
