package org.web3d.x3d.sai;

public interface X3DProtoInstance extends X3DNode {
	public int[] getImplementationTypes();
}
