package org.web3d.x3d.sai;

public class ImportedNodeException extends X3DException {
	public ImportedNodeException() {
		super();
	}
	public ImportedNodeException(String msg) {
		super(msg);
	}
}
