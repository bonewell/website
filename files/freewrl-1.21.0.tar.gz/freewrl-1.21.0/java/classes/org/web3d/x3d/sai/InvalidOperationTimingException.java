package org.web3d.x3d.sai;

public class InvalidOperationTimingException extends X3DException {
	public InvalidOperationTimingException() {
		super();
	}
	public InvalidOperationTimingException(String msg) {
		super(msg);
	}
}
