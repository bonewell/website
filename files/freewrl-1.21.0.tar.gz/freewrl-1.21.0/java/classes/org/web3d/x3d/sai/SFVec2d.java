package org.web3d.x3d.sai;

public interface SFVec2d extends X3DField {
	public void getValue(double[] value);
	public void setValue(double[] value);
}
