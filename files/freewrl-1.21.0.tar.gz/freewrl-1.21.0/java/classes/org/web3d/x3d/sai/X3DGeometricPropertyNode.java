package org.web3d.x3d.sai;

public interface X3DGeometricPropertyNode extends X3DNode {
}
