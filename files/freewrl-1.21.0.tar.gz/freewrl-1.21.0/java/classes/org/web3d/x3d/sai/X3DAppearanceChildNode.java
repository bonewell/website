package org.web3d.x3d.sai;

public interface X3DAppearanceChildNode extends X3DNode {
}
