package org.web3d.x3d.sai;

public class InvalidNameException extends X3DException {
	public InvalidNameException() {
		super();
	}
	public InvalidNameException(String str) {
		super (str);
	}
}
