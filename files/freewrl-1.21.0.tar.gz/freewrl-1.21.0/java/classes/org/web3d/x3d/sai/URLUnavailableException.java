package org.web3d.x3d.sai;

public class URLUnavailableException extends X3DException {
	public URLUnavailableException() {
		super();
	}
	public URLUnavailableException(String msg) {
		super(msg);
	}
}
