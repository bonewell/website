package org.web3d.x3d.sai;

public class InvalidDocumentException extends X3DException {
	public InvalidDocumentException() {
		super();
	}
	public InvalidDocumentException(String msg) {
		super(msg);
	}
}
