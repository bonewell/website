package org.web3d.x3d.sai;

import java.util.*;
import org.web3d.x3d.sai.*;

public interface BrowserListener extends EventListener {
	void browserChanged(BrowserEvent evt);
}
