package org.web3d.x3d.sai;

public interface SFRotation extends X3DField {
	public void getValue(float[] value);
	public void setValue(float[] value);
}
