package org.web3d.x3d.sai;

public interface X3DChildNode extends X3DNode {

}
