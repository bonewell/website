package org.web3d.x3d.sai;

public class NotSupportedException extends X3DException {
	public NotSupportedException() {
		super();
	}
	public NotSupportedException(String msg) {
		super(msg);
	}
}
