package org.web3d.x3d.sai;

public class BrowserNotSharedException extends X3DException {
	public BrowserNotSharedException() {
		super();
	}
	public BrowserNotSharedException(String msg) {
		super(msg);
	}
}
