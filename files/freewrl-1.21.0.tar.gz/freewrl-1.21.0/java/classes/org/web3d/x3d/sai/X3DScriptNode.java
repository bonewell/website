package org.web3d.x3d.sai;

public interface X3DScriptNode extends X3DChildNode, X3DUrlObject {

}
