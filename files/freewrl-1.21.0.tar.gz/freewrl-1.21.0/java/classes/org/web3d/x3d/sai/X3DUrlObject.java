package org.web3d.x3d.sai;

public interface X3DUrlObject {
	public int getNumUrls();
	public void geturl(String[] urls);
	public void setUrl(String[] urls);
}
