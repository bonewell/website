package org.web3d.x3d.sai;

public interface X3DFieldEventListener extends java.util.EventListener {
	public void readableFieldChanged(X3DFieldEvent evt);
}
