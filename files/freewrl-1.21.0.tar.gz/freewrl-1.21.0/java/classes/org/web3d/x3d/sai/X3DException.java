package org.web3d.x3d.sai;

public class X3DException extends RuntimeException {
	public X3DException() {
		super();
	}
	public X3DException(String msg) {
		super (msg);
	}
}
