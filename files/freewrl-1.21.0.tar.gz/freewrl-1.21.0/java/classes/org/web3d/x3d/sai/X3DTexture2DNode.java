package org.web3d.x3d.sai;

public interface X3DTexture2DNode extends X3DTextureNode {
	public void setRepeatS(boolean state);
	public boolean getRepeatS();
	public void setRepeatT(boolean state);
	public boolean getRepeatT();
}
