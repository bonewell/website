package org.web3d.x3d.sai;

public class InvalidFieldValueException extends X3DException {
	public InvalidFieldValueException() {
		super();
	}
	public InvalidFieldValueException(String msg) {
		super (msg);
	}
}
