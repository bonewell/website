package org.web3d.x3d.sai;

public class InvalidX3DException extends X3DException {
	public InvalidX3DException() {
		super();
	}
	public InvalidX3DException(String str) {
		super(str);
	}
}
