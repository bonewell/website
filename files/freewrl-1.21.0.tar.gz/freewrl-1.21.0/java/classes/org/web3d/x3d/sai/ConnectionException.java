package org.web3d.x3d.sai;

public class ConnectionException extends X3DException {
	public ConnectionException() {
		super();
	}
	public ConnectionException(String msg) {
		super(msg);
	}
}
