/*******************************************************************
 Copyright (C) 2003 John Stewart, CRC Canada.
 DISTRIBUTED WITH NO WARRANTY, EXPRESS OR IMPLIED.
 See the GNU Library General Public License (file COPYING in the distribution)
 for conditions of use and redistribution.
*********************************************************************/

/* beginnings of FreeWRL in C */
#include <headers.h>
#include <vrmlconf.h>
#include <Structs.h>
#include "OpenGL_Utils.h"
#include <pthread.h>
#include <PluginSocket.h>
#include <stdlib.h>
#include <unistd.h>
#include <dlfcn.h>

#ifndef AQUA
#include <GL/gl.h>
#include <GL/glx.h>
#include <GL/glu.h>
#else
#include <OpenGL.h>
#endif

#ifdef LINUX
#include <GL/glext.h>
#endif

#include <signal.h>


#include <X11/Intrinsic.h>
#include <X11/StringDefs.h>
#include <X11/Xaw/AsciiText.h>
#include <X11/Xaw/Box.h>
#include <X11/Xaw/Command.h>
#include <X11/Xaw/Dialog.h>
#include <X11/Xaw/MenuButton.h>
#include <X11/Xaw/Paned.h>
#include <X11/Xaw/SimpleMenu.h>
#include <X11/Xaw/SmeBSB.h>
#include <X11/Xaw/SmeLine.h>
#include <X11/Xaw/Sme.h>

/* screen height and width */
int feHeight, feWidth;

extern XtAppContext freewrlXtAppContext;

extern pthread_t DispThrd;
int wantEAI;		/* enable EAI? */
extern int fullscreen;		/* fwopts.c - do fullscreen rendering? */
extern void   XEventStereo(void);

extern void openMainWindow (void);
extern void glpOpenGLInitialize(void);
extern void EventLoop(void);
extern void resetGeometry(void);

/* function prototypes */
void catch_SIGQUIT();
void catch_SIGSEGV();
void catch_SIGHUP();
void catch_SIGALRM(int);
void initFreewrl(void);
extern int parseCommandLine(int, char **);

int main (int argc, char **argv) {
	char *pwd;
	char *initialFilename;	/* file to start FreeWRL with */

	/* first, get the FreeWRL shared lib, and verify the version. */
	if(strcmp(FWVER,getLibVersion())){
  	  ConsoleMessage ("FreeWRL expected library version %s, got %s...\n",FWVER,getLibVersion());
	}

	/* set the screen width and height before getting into arguments */
	feWidth = 600; feHeight=400;
	fullscreen = 0;
	wantEAI = 0;

	/* install the signal handler for SIGQUIT */
	signal (SIGQUIT, (void(*)(int))catch_SIGQUIT);
	signal (SIGTERM, (void(*)(int))catch_SIGQUIT);
	signal (SIGSEGV,(void(*)(int))catch_SIGSEGV);
	signal (SIGALRM,(void(*)(int))catch_SIGALRM);
	signal (SIGHUP, (void(*)(int))catch_SIGHUP);

	/* parse command line arguments */
	/* JAS - for last parameter of long_options entries, choose
	 * ANY character that is not 'h', and that is not used */
	if (parseCommandLine (argc, argv)) {
        	/* create the initial scene, from the file passed in
        	  and place it as a child of the rootNode. */

        	initialFilename = (char *)MALLOC(1000 * sizeof (char));
        	pwd = (char *)MALLOC(1000 * sizeof (char));
        	getcwd(pwd,1000);
        	/* if this is a network file, leave the name as is. If it is
        	   a local file, prepend the path to it */


	        if (checkNetworkFile(argv[optind])) {
			setFullPath(argv[optind]);
	
	        } else {
	                makeAbsoluteFileName(initialFilename, pwd, argv[optind]);
	                setFullPath(initialFilename);
	        }
		FREE_IF_NZ (initialFilename);
	} else {
		BrowserFullPath = NULL;
	}


	/* start threads, parse initial scene, etc */
	initFreewrl();

	/* do we require EAI? */
	if (wantEAI) create_EAI();

	/* now wait around until something kills this thread. */
	pthread_join(DispThrd, NULL);
}


static int CaughtSEGV = FALSE;
/* SIGQUIT handler - plugin code sends a SIGQUIT... */
void catch_SIGQUIT() {
		/* ConsoleMessage ("FreeWRL got a sigquit signal"); */
/*
	 shut up any SIGSEGVs we might get now.
	*/
	CaughtSEGV = TRUE;
    	doQuit();
}
void catch_SIGHUP() {
		/* ConsoleMessage ("FreeWRL got a SIGHUP signal - reloading"); */
		Anchor_ReplaceWorld (BrowserFullPath);
}


void catch_SIGSEGV() {
	if (!CaughtSEGV) {
		ConsoleMessage ("FreeWRL got a SIGSEGV - can you please mail the file(s) to\n freewrl-09@rogers.com with a valid subject line. Thanks.\n");
		CaughtSEGV = TRUE;
	}
    exit(1);
}

void catch_SIGALRM(int sig)
{
    signal(SIGALRM, SIG_IGN);

    /* stuffs to do on alarm */
    /* fprintf(stderr,"An alarm signal just arrived ...IT WAS IGNORED!\n"); */
    /* end of alarm actions */

    alarm(0);
    signal(SIGALRM, catch_SIGALRM);
}
