
class AnimationServer {

    public static void main(String[] args) {
      new AnimationServerMain().run();
    }

}

